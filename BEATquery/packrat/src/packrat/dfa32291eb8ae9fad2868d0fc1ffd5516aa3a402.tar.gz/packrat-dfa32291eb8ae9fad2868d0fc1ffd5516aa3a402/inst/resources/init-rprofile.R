#### -- Packrat Autoloader (version 0.4.6-9) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
